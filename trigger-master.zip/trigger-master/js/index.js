// function sendEmail() {
// 	Email.send({
// 	Host: "smtp.gmail.com",
// 	Username : "trigger.superfluo@gmail.com",
// 	Password : "piamose18",
// 	// To : 'gurki4.mm@gmail.com',
// 	To : '',
// 	From : "trigger.superfluo@gmail.com",
// 	Subject : "<email subject>",
//     Body : "<email body>",
//     Attachments : [
//         {
//             name : "smtpjs.png",
//             path : "https://networkprogramming.files.wordpress.com/2017/11/smtpjs.png"
//         }]  
// 	}).then(
// 		message => alert("mail sent successfully")
// 	);
// }